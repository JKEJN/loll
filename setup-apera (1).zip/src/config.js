require("dotenv").config();

module.exports = {
    token: process.env.TOKEN || "OTQ5MjQxMjI5NTkyMzc5NDMy.YiHfyQ.C_WUtFQS8icQJ82Th4oepXSRizk",//OTQ5MjQxMjI5NTkyMzc5NDMy.YiHfyQ.C_WUtFQS8icQJ82Th4oepXSRizk
    prefix: process.env.PREFIX || "?", // bot prefix
    ownerID: process.env.OWNERID || "952560202635427841", //your discord id
    SpotifyID: process.env.SPOTIFYID || "69ebbd15cba9474a9d46e5aa95733b15", // spotify client id
    SpotifySecret: process.env.SPOTIFYSECRET || "185da21de3904b7db61d4d12c455c166", // spotify client secret
    mongourl: process.env.MONGO_URI || "mongodb+srv://AkAbhijit:6291@apera.rucws.mongodb.net/aperaprime", // MongoDb URL
    embedColor: process.env.COlOR || "#5865F2", // embed colour
    links: 
        {
            support: "https://discord.gg/tKt9WSBEVT",
            img:"https://media.discordapp.net/attachments/952583483891535922/962731397137719337/20220410_002237.jpg",
            bg:"https://media.discordapp.net/attachments/952583483891535922/962731397137719337/20220410_002237.jpg",
            invite:"https://top.gg/bot/963480000001081404/invite",
            vote:"https://top.gg/bot/963480000001081404/vote",
        },
        webhook: 
        {
            gjoin: {
                id:"960087092896092201",
                token:"aUHacAnL9pMbxK0doZP0yB-T2OFkvCEl4YjPIIf1RucIKpkJ2CUA24g-YdwwX2B1eQxu",
            },
            gleave:{
                id:"960087341819625502",
                token:"m9JfM8K1JulSC7CgkW8A2p4cGs17rCGFU0hsTXeCBK-ESHTp1RMQG0JPAUQHnAbVTqrs",
            },
            ready:{
                id:"960086748396941352",
                token:"mb8vyWI5X1qq3KllM-_dBLNuFjOw2imTMuL53wHATlChchmANmedKNhCTVC3Znn4sbZP",
            },
            error:{
                id:"960087742484717568",
                token:"-FKryyLeyXIDxoYV_hUblTD_opSjlJYoQZTP7gfATx2HQTTbeQvAV_ZattJq3rm9GHWf",
            },
            lavalink:{
                id:"960087841122189312",
                token:"A4YM75e_V1WMx-aJRlbuUB2ExAu7Sd0PgtPqVhPXrVaxdVWOpZXnjNyn3gxO-ft7I7Ts",
            },
            player:{
                id:"960087960974413824",
                token:"xeQwwy2dYixusCju3cDrSTuRUr_6ISz6foz6jkqttkDQx3UAtth81b_bnP6SQaXMDKow",
            },
            setupdata:{
                id:"960103812268445706",
                token:"J6E-idpHJSws4wA3nK9ZGDKkoLL1q3O_snmt8cSqMdqRfJ-Mp1nwnXOtjaKH0-MJeEsA",
            },
        },

    nodes: [
    {
      host: process.env.NODE_HOST || "ec2-50-19-31-157.compute-1.amazonaws.com",
      identifer: process.env.NODE_ID || "local",
      port: parseInt(process.env.NODE_PORT || "80"),
      password: process.env.NODE_PASSWORD || "coders",
      secure: parseBoolean(process.env.NODE_SECURE || "false"),

    }
  ],
 
}

function parseBoolean(value){
    if (typeof(value) === 'string'){
        value = value.trim().toLowerCase();
    }
    switch(value){
        case true:
        case "true":
            return true;
        default:
            return false;
    }
}
