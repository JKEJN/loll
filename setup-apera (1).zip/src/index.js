const MusicBot = require("./structures/MusicClient");
const client = new MusicBot();

client.connect()

module.exports = client; 
