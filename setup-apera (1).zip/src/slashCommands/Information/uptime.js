const { MessageEmbed, version } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");
const os = require("os");
const si = require("systeminformation");

module.exports = {
    name: "uptime",
    description: "Show Uptime Status",
    run: async (client, interaction) => {
        await interaction.deferReply({
            ephemeral: false
        });
        const d = moment.duration(client.uptime);
        const days = d.days() == 1 ? `${d.days()}d` : `${d.days()}d`;
        const hours = d.hours() == 1 ? `${d.hours()}h` : `${d.hours()}h`;
        const minutes = d.minutes() == 1 ? `${d.minutes()}m` : `${d.minutes()}m`;
        const seconds = d.seconds() == 1 ? `${d.seconds()}s` : `${d.seconds()}s`;
        const up = `**Uptime**:\`${days} ${hours} ${minutes} ${seconds}\``;
        interaction.followUp(up);
    },
};