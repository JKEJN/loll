
const { MessageEmbed, CommandInteraction, Client } = require("discord.js");
const { version } = require("discord.js");
const Discord = require("discord.js")
const moment = require("moment");
require("moment-duration-format");
const os = require('os')
const si = require('systeminformation');

module.exports = {
    name: "status",
    description: "Show status bot",
    run: async (client, interaction) => {

        await interaction.deferReply({
            ephemeral: false
        });
        let connectedchannelsamount = 0;
        let guilds = client.guilds.cache.map((guild) => guild);
        for (let i = 0; i < guilds.length; i++) {
            if (guilds[i].me.voice.channel) connectedchannelsamount += 1;
        }
        if (connectedchannelsamount > client.guilds.cache.size)
            connectedchannelsamount = client.guilds.cache.size;
        var color = client.embedColor;

        let commands = client.commands.filter((x) => x.category && x.category !== "Owner").map((x) => `\`${x.name}\``).length
        const statsEmbed = new MessageEmbed()
            .setAuthor({ name: `My Stats`, iconURL: client.user.displayAvatarURL() })
            .setColor(color)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setDescription(`\n`)
            .addFields(
                { name: `  **Platform**`, value: `• \`[ ${os.type} ]\``, inline: true },
                { name: `  **Up Since**`, value: "• <t:" + Math.round((Date.now() - interaction.client.uptime) / 1000) + ":R>", inline: true },
                { name: `  **Ping**`, value: `• \`[ ${client.ws.ping} ]\``, inline: true },
                { name: `  **Server(s)**`, value: `• \`[ ${client.guilds.cache.size} ]\``, inline: true },
                {
                    name: `  **User(s)**`, value: `• \`[${client.guilds.cache.reduce(
                        (acc, guild) => acc + guild.memberCount,
                        0
                    )}  ]\``, inline: true
                },
                { name: `  **Channel(s)**`, value: `• \`[ ${client.channels.cache.size} ]\``, inline: true },
                { name: `  **Player(s)**`, value: `• \`[ ${connectedchannelsamount} ]\``, inline: true },
                { name: `  **Command(s)**`, value: `• \`[ ${commands} ]\``, inline: true },
                { name: `  **Discord.js**`, value: `• \`[ v${version} ]\``, inline: true },

            )
        interaction.followUp({ embeds: [statsEmbed] });


    }
}