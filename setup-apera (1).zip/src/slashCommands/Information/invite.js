const { MessageEmbed, CommandInteraction, Client, MessageButton, MessageActionRow } = require("discord.js")

module.exports = {
  name: "invite",
  description: "Get The Bot Invite Link",

  /**
   * 
   * @param {Client} client 
   * @param {CommandInteraction} interaction 
   */

  run: async (client, interaction) => {
    await interaction.deferReply({
      ephemeral: false
    });

    var invite = client.config.links.invite;
    var support = client.config.links.support;

    var color = client.embedColor
    const row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setLabel("Invite")
          .setStyle("LINK")
          .setURL(invite),

          new MessageButton()
          .setLabel("Support Server")
          .setStyle("LINK")
          .setURL(support)

      );


    const mainPage = new MessageEmbed()
    .setDescription(`Click [Here](${invite}) To Invite Me Or Click Below\n\n For Any Query About Bot Don't Hesitate To Join [Support Server](${support}) `)
      .setColor(color)
    interaction.editReply({ embeds: [mainPage], components: [row] })
  }
}