const { MessageEmbed, CommandInteraction, Client, Permissions, MessageButton, MessageActionRow } = require("discord.js")
const { convertTime } = require('../../utils/convert.js');

module.exports = {
  name: "grab",
  description: "Grabs And Sends You The Song That Is Playing At The Moment",
  /**
   * 
   * @param {Client} client 
   * @param {CommandInteraction} interaction 
   */

  run: async (client, interaction) => {
   
    if(!interaction.member.voice.channel) return interaction.editReply({embeds: [new MessageEmbed ().setColor(client.embedColor).setDescription("You are not connect in vc")]});

    let player = interaction.client.manager.get(interaction.guildId);
    if (!player.queue.current) {
        let thing = new MessageEmbed()
        .setColor("#FFC942")
        .setDescription("Currently No Music Is Playing.");
        return interaction.reply({embeds: [thing]});
    }

    const track = player.queue.current
    const total = track.duration;
    const current = player.position;

    const dmbut = new MessageButton().setLabel("Check Your Dm").setStyle("LINK").setURL(`https://discord.com/users/${client.id}`)
    const row = new MessageActionRow().addComponents(dmbut)

    let dm = new MessageEmbed()
    .setAuthor({name: interaction.user.tag, iconURL: interaction.user.avatarURL()})
    .setDescription(`:mailbox_with_mail: \`Check Your Dms!\``)
    .setColor(client.embedColor)
    .setFooter({text: `Requested By ${interaction.user.tag}`})
    interaction.reply({embeds: [dm], components: [row]})
    const user = client.users.cache.get(interaction.member.user.id);
    const urlbutt = new MessageButton().setLabel("Search").setStyle("LINK").setURL(track.uri)
    const row2 = new MessageActionRow().addComponents(urlbutt)
    let embed = new MessageEmbed()
        .setDescription(`**Song Details** \n\n > \`[ Song Name ]\`: [${track.title}](${track.uri}) \n > \`[ Song Duration ]\`: \`[${convertTime(track.duration)}]\` \n > \`[ Song Played By ]\`: [<@${track.requester.id}>] \n > \`[ Song Saved By ]\`: [<@${interaction.user.id}>]`)
        .setThumbnail(track.displayThumbnail())
        .setColor(client.embedColor)
        .addField("\u200b", `\`${convertTime(current)} / ${convertTime(total)}\``)
     return user.send({embeds: [embed], components: [row2]})

   }
};
