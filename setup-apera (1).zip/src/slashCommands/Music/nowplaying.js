const { MessageEmbed, CommandInteraction, Client } = require("discord.js")
const { convertTime } = require('../../utils/convert.js');
const { progressbar } = require('../../utils/progressbar.js')

module.exports = {
    name: "nowplaying",
    description: "Show now playing song",
    /**
     * 
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */

    run: async (client, interaction) => {
        await interaction.deferReply({
          ephemeral: false
        });
         const player = interaction.client.manager.get(interaction.guildId);

        if (!player.queue.current) {
            let thing = new MessageEmbed()
                .setColor("RED")
                .setDescription("Currently No Music Is Playing.");
            return interaction.editReply({embeds: [thing]});
        }

        const track = player.queue.current

        var total = track.duration;
        var current = player.position;

        let embed = new MessageEmbed()
            .addField(`**Now Playing**`,`[${track.title}](${track.uri})`)
            .addField(`Duration`,`\`[ ${convertTime(total)} ]\``, true)
            .addField(`Author`,`${player.queue.current.author}`, true)
            .addField(`Requested by`,`[ ${track.requester} ]`,true)
            .setThumbnail(`https://img.youtube.com/vi/${track.identifier}/mqdefault.jpg`)
            .setColor(client.embedColor)
            .addField(`**Progress Bar**`, `**[ ${progressbar(player)}** ] \n\`${convertTime(player.position)}  ${convertTime(total)}\``)
            return interaction.editReply({embeds: [embed]})
            
    }
};
