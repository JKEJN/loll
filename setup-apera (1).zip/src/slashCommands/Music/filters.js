const { MessageEmbed, CommandInteraction, Client } = require("discord.js")

module.exports = {
  name: "filters",
  description: "Set EqualizerBand",
  options: [
    {
        name: "filter",
        description: "Set EqualizerBand",
        type: "STRING",
        required: true,
        choices: [
            {
                name: "Disable",
                value: "clear"
            },
            {
                name: "8D",
                value: "8d",
            },
            {
                name: "Bass",
                value: "bass"
            },
            {
                name: "Bassboost",
                value: "bassboost"
            },
            {
                name: "Distort",
                value: "distort"
            }, 
            {
                name: "Earrape",
                value: "earrape"
            },
            {
                name: "Electronic",
                value: "electronic"
            },
            {
                name: "Equalizer",
                value: "equalizer"
            },
            {
                name: "NightCore",
                value: "nightcore"
            },
            {
                name: "Party",
                value: "party"
            },
            {
                name: "Pitch",
                value: "pitch"
            },
            {
                name: "Radio",
                value: "radio"
            },
            {
                name: "Soft",
                value: "soft"
            },
            {
                name: "Speed",
                value: "speed"
            },
            {
                name: "TrebleBass",
                value: "treblebass"
            },
            {
                name: "VaporWave",
                value: "vaporwave"
            }

        ]
    }  
],

  /**
   * 
   * @param {Client} client 
   * @param {CommandInteraction} interaction 
   */

  run: async (client, interaction) => {
    await interaction.deferReply({
      ephemeral: false
    });
      if(!interaction.member.voice.channel) return interaction.editReply({embeds: [new MessageEmbed ().setColor(client.embedColor).setDescription("You are not connect in vc")]});
      if(interaction.guild.me.voice.channel && interaction.guild.me.voice.channelId !== interaction.member.voice.channelId) return interaction.editReply({embeds: [new MessageEmbed ().setColor(client.embedColor).setDescription(`You are not connected to <#${interaction.guild.me.voice.channelId}> to use this command.`)]});
    const filter = interaction.options.getString("filter");

    const player = interaction.client.manager.get(interaction.guildId);
    if (!player.queue.current) {
      const thing = new MessageEmbed()
        .setDescription('there is nothing playing')
        .setColor(client.embedColor)
      return interaction.editReply({ embeds: [thing] });
     }

        let thing = new MessageEmbed()
            .setColor(client.embedColor)
       switch(filter) {   
       
        case '8d':
            player.set8D(true);
            thing.setDescription(`8D Mode Is Now Enabled.`);
            break;
        case 'bass':   
            player.setBassboost(true);
            thing.setDescription(`Bass Mode Is Now Enabled.`);
            break;
        case 'bassboost':
            var bands = new Array(7).fill(null).map((_, i) => (
                { band: i, gain: 0.25 }
            ));
            player.setEQ(...bands);
            thing.setDescription(`BassBoost Mode Is Now Enabled.`);
            break;
        case'distort':
            player.setDistortion(true); 
            thing.setDescription(`Distort Mode Is Now Enabled.`);
            break;
            case'earrape':   
            var earrape = [
                500
            ];
            await player.setVolume(earrape);
            thing.setDescription(`EarRape Mode Is Now Enabled.`);
            break;
        case'electronic':
        var bands = [
            { band: 0, gain: 0.375 },
            { band: 1, gain: 0.350 },
            { band: 2, gain: 0.125 },
            { band: 3, gain: 0 },
            { band: 4, gain: 0 },
            { band: 5, gain: -0.125 },
            { band: 6, gain: -0.125 },
            { band: 7, gain: 0 },
            { band: 8, gain: 0.25 },
            { band: 9, gain: 0.125 },
            { band: 10, gain: 0.15 },
            { band: 11, gain: 0.2 },
            { band: 12, gain: 0.250 },
            { band: 13, gain: 0.350 },
            { band: 14, gain: 0.400 }
        ]
        await player.setEQ(...bands);
            thing.setDescription(`Electronic Mode Is Now Enabled.`);
            break;
        case 'equalizer': 
        await player.setEqualizer(true);
            thing.setDescription(`Equalizer Mode Is Now Enabled.`);
            break;
        case 'nightcore': 
        await player.setNightcore(true);
            thing.setDescription(`NightCore Mode Is Now Enabled.`);
            break;
        case 'party': 
        var bands = [
            { band: 0, gain: -1.16 },
            { band: 1, gain: 0.28 },
            { band: 2, gain: 0.42 },
            { band: 3, gain: 0.5 },
            { band: 4, gain: 0.36 },
            { band: 5, gain: 0 },
            { band: 6, gain: -0.3 },
            { band: 7, gain: -0.21 },
            { band: 8, gain: -0.21 },
          ];
          await player.setEQ(...bands);
            thing.setDescription(`Party Mode Is Now Enabled.`);
            break;
        case 'radio': 
        var bands = [
            { band: 0, gain: -0.25 },
            { band: 1, gain: 0.48 },
            { band: 2, gain: 0.59 },
            { band: 3, gain: 0.72 },
            { band: 4, gain: 0.56 },
            { band: 5, gain: 0.15 },
            { band: 6, gain: -0.24 },
            { band: 7, gain: -0.24 },
            { band: 8, gain: -0.16 },
            { band: 9, gain: -0.16 },    
            { band: 10, gain: 0 },    
            { band: 11, gain: 0 },
            { band: 12, gain: 0 },   
            { band: 13, gain: 0 },
            { band: 14, gain: 0 }
        ];
        await player.setEQ(...bands);
            thing.setDescription(`Radio Mode Is Now Enabled.`);
            break;
        case 'soft': 
        var bands = [
            { band: 0, gain: 0 },
            { band: 1, gain: 0 },
            { band: 2, gain: 0 },
            { band: 3, gain: 0 },
            { band: 4, gain: 0 },
            { band: 5, gain: 0 },
            { band: 6, gain: 0 },
            { band: 7, gain: 0 },
            { band: 8, gain: -0.25 },
            { band: 9, gain: -0.25 },
            { band: 10, gain: -0.25 },
            { band: 11, gain: -0.25 },
            { band: 12, gain: -0.25 },
            { band: 13, gain: -0.25 },
            { band: 14, gain: -0.25 },
          ];
          await player.setEQ(...bands);
            thing.setDescription(`Soft Mode Is Now Enabled.`);
            break;
        case 'speed': 
        await player.setSpeed(2);
            thing.setDescription(`Speed Mode Is Now Enabled.`);
            break;
        case 'treblebass': 
        var bands = [
            { band: 0, gain: 0.6 },
            { band: 1, gain: 0.67 },
            { band: 2, gain: 0.67 },
            { band: 3, gain: 0 },
            { band: 4, gain: -0.5 },
            { band: 5, gain: 0.15 },
            { band: 6, gain: -0.45 },
            { band: 7, gain: 0.23 },
            { band: 8, gain: 0.35 },
            { band: 9, gain: 0.45 },
            { band: 10, gain: 0.55 },
            { band: 11, gain: 0.6 },
            { band: 12, gain: 0.55 },
            { band: 13, gain: 0 },
            { band: 14, gain: 0 },
          ];
          await player.setEQ(...bands);
            thing.setDescription(`TrebleBass Mode Is Now Enabled.`);
            break;
        case 'vaporwave': 
        await player.setVaporwave(true);
            thing.setDescription(`VaporWave Mode Is Now Enabled.`);
            break;
        case 'clear': 
        await player.clearEffects();
            thing.setDescription(`Disabled All Filters.`);
        }
         return interaction.editReply({embeds: [thing]});
    }
};
