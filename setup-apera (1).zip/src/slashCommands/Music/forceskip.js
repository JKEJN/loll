const { MessageEmbed, CommandInteraction, Client } = require("discord.js")

module.exports = {
    name: "forceskip",
    description: "To force skip the current playing song.",
	
    /**
     * 
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */

    run: async (client, interaction) => {
        await interaction.deferReply({
            ephemeral: false
          });
          const player = interaction.client.manager.get(interaction.guild.id);

          if (!player.queue.current) {
              let thing = new MessageEmbed()
                  .setColor("RED")
                  .setDescription("Currently No Music Is Playing.");
           return interaction.followUp({embeds: [thing]});
          }
          const track = player.queue.current;
  
             player.stop();
             
  
          let thing = new MessageEmbed()
              .setDescription(`Skipped - [${track.title}](${track.uri})`)
              .setColor(client.embedColor)
          return interaction.followUp({embeds: [thing]})
      
      }
  };     


    