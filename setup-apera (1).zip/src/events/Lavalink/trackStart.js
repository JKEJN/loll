const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const { convertTime } = require('../../utils/convert.js');
const { trackStartEventHandler } = require("../../utils/functions");
const db = require("../../schema/setup");

module.exports = async (client, player, track, payload) => {
  let guild = client.guilds.cache.get(player.guild);
  if (!guild) return;
  let channel = guild.channels.cache.get(player.textChannel);
  if (!channel) return;
  let data = await db.findOne({ Guild: guild.id });
  if (data && data.Channel) {
    let textChannel = guild.channels.cache.get(data.Channel);
    const id = data.Message;
    if (channel.id === textChannel.id) {
      return await trackStartEventHandler(id, textChannel, player, track, client);
    } else {
      await trackStartEventHandler(id, textChannel, player, track, client);
    };
  }

  const emojiplay = client.emoji.play;
  var icon;
  if (track.uri.includes("open.spotify")) {
    let fetch = require('isomorphic-unfetch');
    let { getPreview } = require('spotify-url-info')(fetch)
    let tobereturned = getPreview(player.queue.current.uri).catch(() => { })
    icon = (await tobereturned).image;
  } else icon = `https://img.youtube.com/vi/${player.queue.current.identifier}/maxresdefault.jpg`
  const thing = new MessageEmbed()
    .setTitle(`${emojiplay} Now Playing`)
    .setDescription(`[${track.title}](${track.uri}) - ${track.requester ? track.requester.username : "Unknown User"}`)
    .setColor(client.embedColor);

  const m = channel.send({ embeds: [thing] });

  await player.setNowplayingMessage(m);

};
