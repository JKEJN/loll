const { MessageActionRow, MessageButton } = require("discord.js");
const db = require("../../schema/setup");
const { WebhookClient, MessageEmbed } = require('discord.js');
const moment = require('moment');

module.exports = async (client, player) => {
	const webhook = new WebhookClient({ id: client.config.webhook.player.id, token: client.config.webhook.player.token })
	var embed = new MessageEmbed()
		.setDescription(`Player has been created in **${player.guild}**.`)
		.setColor(client.embedColor)
	webhook.send({ embeds: [embed] });

	let guild = client.guilds.cache.get(player.guild);
	if (!guild) return;
	const data = await db.findOne({ Guild: guild.id });
	if (!data) return;

	let channel = guild.channels.cache.get(data.Channel);
	if (!channel) return;

	let message;

	try {

		message = await channel.messages.fetch(data.Message, { cache: true });

	} catch (e) { };

	if (!message) return;
	
	let disabled = true;
	if(player) disabled = false;
	if (player && player.queue && player.queue.current) disabled = false;

	let pausebut = new MessageButton().setCustomId(`pause_but_${guild.id}`).setEmoji("⏯️").setStyle("SECONDARY");

	let lowvolumebut = new MessageButton().setCustomId(`lowvolume_but_${guild.id}`).setEmoji("🔉").setStyle("SECONDARY");

	let highvolumebut = new MessageButton().setCustomId(`highvolume_but_${guild.id}`).setEmoji("🔊").setStyle("SECONDARY");

	let previousbut = new MessageButton().setCustomId(`previous_but_${guild.id}`).setEmoji("⏮️").setStyle("SECONDARY");

	let skipbut = new MessageButton().setCustomId(`skipbut_but_${guild.id}`).setEmoji("⏭️").setStyle("SECONDARY");

	let rewindbut = new MessageButton().setCustomId(`rewindbut_but_${guild.id}`).setEmoji("⏪").setStyle("SECONDARY");

	let forwardbut = new MessageButton().setCustomId(`forward_but_${guild.id}`).setEmoji("⏩").setStyle("SECONDARY");

	let savebut = new MessageButton().setCustomId(`save_but_${guild.id}`).setEmoji("♾️").setStyle("SECONDARY");

	let loopmodesbut = new MessageButton().setCustomId(`loopmodesbut_but_${guild.id}`).setEmoji("🔁").setStyle("SECONDARY");

	let stopbut = new MessageButton().setCustomId(`stop_but_${guild.id}`).setEmoji("⏹️").setStyle("SECONDARY");

	const row1 = new MessageActionRow().addComponents([lowvolumebut, previousbut, pausebut, skipbut, highvolumebut]);

	const row2 = new MessageActionRow().addComponents([rewindbut, savebut, stopbut, loopmodesbut, forwardbut]);

	await message.edit({ content: "__**Join a voice channel and queue songs by name/url.**__\n\n", components: [row1, row2] }).catch(() => { });


}