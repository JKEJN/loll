const { WebhookClient, MessageEmbed } = require('discord.js');
const moment = require('moment');
module.exports = async (client, node) => {

	const webhook = new WebhookClient({ id: client.config.webhook.lavalink.id, token: client.config.webhook.lavalink.token })
	var embed = new MessageEmbed()
		.setDescription(`Node \`[ ${node.options.identifier} ]\` created.`)
		.setColor(client.embedColor)
	webhook.send({ embeds: [embed] });

}