const { MessageEmbed } = require("discord.js");

module.exports = async (client, player, track, payload) => {

    console.error(payload.error);

    const channel = client.channels.cache.get(player.textChannel);
    const thing = new MessageEmbed()
        .setColor("RED")
        .setDescription("❌ Error when loading song! Track is error");
    channel.send({ embeds: [thing] }).then(msg => { setTimeout(() => { msg.delete() }, 5000) });

    const { WebhookClient } = require('discord.js');
    const moment = require('moment');

    const webhook = new WebhookClient({ id: client.config.webhook.player.id, token: client.config.webhook.player.token })
    var embed = new MessageEmbed()
        .setDescription(`Error when loading song! Track is error in [ ${player.guild} ]`)
        .setColor(client.embedColor)
    webhook.send({ embeds: [embed] });
    if (!player.voiceChannel) player.destroy();

}