const{ WebhookClient }= require('discord.js')
module.exports = {
  name: "rateLimit",
  run: async (client, rateLimitData) => {
    const webhook = new WebhookClient({id:client.config.webhook.error.id, token : client.config.webhook.error.token})
  webhook.send(rateLimitData);
  }
};
