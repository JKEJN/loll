const { MessageEmbed } = require("discord.js");
const { convertTime } = require('../../utils/convert.js');
const { progressbar } = require('../../utils/progressbar.js')

module.exports = {
    name: "nowplaying",
    aliases: ["np"],
    category: "Music",
    description: "Show now playing track",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    player: true,
    inVoiceChannel: false,
    sameVoiceChannel: false,
execute: async (message, args, client, prefix) => {
  
        const player = message.client.manager.get(message.guild.id);
        const track = player.queue.current


        if (!player.queue.current) {
            let thing = new MessageEmbed()
                .setColor("RED")
                .setDescription("Currently No Music Is Playing.");
            return message.channel.send(thing);
        }
        
        const emojimusic = client.emoji.music;
        var total = track.duration;
        var current = player.position;
        var icon;
        if (track.uri.includes("open.spotify")) {
          let fetch = require('isomorphic-unfetch');
          let { getPreview } = require('spotify-url-info')(fetch)
          let tobereturned = getPreview(player.queue.current.uri).catch(() => { })
          icon = (await tobereturned).image;
        } else icon = `https://img.youtube.com/vi/${player.queue.current.identifier}/maxresdefault.jpg`
        
        let embed = new MessageEmbed()
            .addField(`${emojimusic} **Now Playing**`,`[${track.title}](${track.uri})`)
            .addField(`Duration`,`\`[ ${convertTime(total)} ]\``, true)
            .addField(`Author`,`${player.queue.current.author}`, true)
            .addField(`Requested by`,`[ ${track.requester} ]`,true)
            .setThumbnail(icon)
            .setColor(client.embedColor)
            .addField(`**Progress Bar**`, `**[ ${progressbar(player)}** ] \n\`${convertTime(current)}  ${convertTime(total)}\``)
            return message.channel.send({embeds: [embed]})

    }
}
