const { MessageEmbed } = require("discord.js");

module.exports = {
	name: "leave",
    aliases: ["dc"],
    category: "Music",
    description: "Leave voice channel",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    player: false,
    inVoiceChannel: true,
    sameVoiceChannel: true,
 execute: async (message, args, client, prefix) => {
       
        const player = message.client.manager.get(message.guild.id);

        player.destroy();
        const { channel } = message.member.voice;
        let thing = new MessageEmbed()
            .setColor(message.client.embedColor)
            .setDescription(`Player is now stopped/destroyed in <#${channel.id}>.`)
          return message.reply({embeds: [thing]});
	
    }
};