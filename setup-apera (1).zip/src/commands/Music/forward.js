const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");
const { convertTime } = require("../../utils/convert.js");
module.exports = {
  name: "forward",
  aliases: ["f"],
  category: "Music",
  description: "To foward the current playing song 10s as default.",
  args: false,
  usage: "[position]",
  permission: [],
  owner: false,
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (message, args, client, prefix) => {
    const player = client.manager.get(message.guild.id);
    const track = player.queue.current;
    const duration  = player.queue.current;
    let color = client.embedColor;

    if (!track)
      return message.reply({
        embed: [new MessageEmbed()
          .setColor(color)
          .setDescription(`Currently No Music Is Playing.`)]
      })

    let forwardposition = Number(player.position) + 10000;

    if (forwardposition >= duration) return message.reply({ embeds: [new MessageEmbed().setDescription(`Cannot forward any further more.`).setColor(client.embedColor)], });

    if (player.paused)
      return message.reply({ embeds: [new MessageEmbed().setDescription(`Cannot forward because the player is currently paused.`).setColor(client.embedColor)] });

    if (!player.queue.current.isSeekable) return message.reply({ embeds: [new MessageEmbed().setDescription(`Unable to forward this track.`).setColor(client.embedColor)] });

    if (Number(args[0]) <= 0) forwardposition = Number(player.position);

    if (Number(forwardposition) >= player.queue.current.duration)
      forwardposition = player.queue.current.duration - 1000;
    //seek to the new Seek position
    player.seek(Number(forwardposition));
    let amount = args[0]
    message.reply({
      embeds: [new MessageEmbed()
        .setDescription(`Forwarded \`[ ${amount ? `${args[0]}` : `10`}s ]\` to \`[ ${convertTime(Number(player.position))} / ${convertTime(Number(duration))} ]\``)
        .setColor(client.embedColor)],
    });
  },
};
