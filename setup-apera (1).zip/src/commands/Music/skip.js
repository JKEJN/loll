const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "skip",
  aliases: ["s"],
  category: "Music",
  description: "To skip the current playing song.",
  args: false,
  usage: "",
  permission: [],
  owner: false,
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  execute: async (message, args, client, prefix) => {
    const player = message.client.manager.get(message.guild.id);

    if (!player.queue.current) {
      let thing = new MessageEmbed()
        .setColor("RED")
        .setDescription("Currently No Music Is Playing.");
      return message.reply({ embeds: [thing] });
    }
    if (player.queue.size == 0) {
      let noskip = new MessageEmbed()
        .setColor(client.embedColor)
        .setDescription(`No more songs left in the queue to skip.`);
      return message.reply({ embeds: [noskip] });
    }
    const track = player.queue.current;

    player.stop();

    let thing = new MessageEmbed()
      .setDescription(`**Skipped** [${track.title}](${track.uri})`)
      .setColor(message.client.embedColor)
    return message.reply({ embeds: [thing] })

  },
};
