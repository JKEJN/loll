const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");
const { convertTime } = require("../../utils/convert.js");

module.exports = {
  name: "rewind",
  aliases: ["backward"],
  category: "Music",
  description: "To rewind the current playing song 10s as default.",
  args: false,
  usage: "rewind [position]",
  permission: [],
  owner: false,
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (message, args, client, prefix) => {
    const player = client.manager.get(message.guild.id);
    const { duration } = player.queue.current;


    let rewindposition = Number(player.position) - 10000;
    //if the userinput is smaller then 0, then set the seektime to just the player.position
    if (rewindposition < 0)
      return message.reply({
        embeds: [
          new MessageEmbed()
            .setDescription(`Cannot rewind any further more.`)
            .setColor(client.embedColor),
        ],
      });
    if (player.paused)
      return message.reply({
        embeds: [
          new MessageEmbed()
            .setDescription(
              `Cannot rewind because the player is currently paused.`
            )
            .setColor(client.embedColor),
        ],
      });
    if (!player.queue.current.isSeekable) return message.reply({ embeds: [new MessageEmbed().setDescription(`Unable to rewind this track.`).setColor(client.embedColor)] });

    if (
      rewindposition >= player.queue.current.duration - player.position || rewindposition < 0
    ) {
      rewindposition = 0;
    }
    //seek to the new Seek position
    player.seek(Number(rewindposition));
    let amount = args[0]
    //Send Success Message
    message.reply({
      embeds: [
        new MessageEmbed()
          .setDescription(
            `Rewinded \`[ ${amount ? `${args[0]}` : `10`}s ]\` to \`[ ${convertTime(
              Number(player.position)
            )} / ${convertTime(Number(duration))} ]\``
          )
          .setColor(client.embedColor),
      ],
    });
  },
};
