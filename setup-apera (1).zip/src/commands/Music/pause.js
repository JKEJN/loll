const { MessageEmbed } = require("discord.js");

module.exports = {
    name: "pause",
    category: "Music",
    description: "Pause the currently playing music",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    player: true,
    inVoiceChannel: true,
    sameVoiceChannel: true,
    execute: async (message, args, client, prefix) => {

        const player = message.client.manager.get(message.guild.id);

        if (!player.queue.current) {
            let thing = new MessageEmbed()
                .setColor("RED")
                .setDescription("Currently No Music Is Playing.");
            return message.reply({ embeds: [thing] });
        }
        if (player.paused) {
            let thing = new MessageEmbed()
                .setColor("RED")
                .setDescription(`The player is already paused.`)
            return message.reply({ embeds: [thing] });
        }
        player.pause(true);
        const track = player.queue.current;

        let thing = new MessageEmbed()
            .setColor(client.embedColor)
            .setDescription(`[${track.title}](${track.uri}) is now paused.`)
        return message.reply({ embeds: [thing] });

    }
};
