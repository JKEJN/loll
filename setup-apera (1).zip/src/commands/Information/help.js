const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");

module.exports = {
    name: "help",
    category: "Information",
    aliases: ["h"],
    description: "Return all commands, or one specific command",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    execute: async (message, args, client, prefix) => {

        if (client.config.ownerID === message.author.id) {
            if(!args[0]){
            const color = client.embedColor
            var row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setLabel('Invite')
                        .setURL(client.config.links.invite)
                        .setStyle('LINK'),

                    new MessageButton()
                        .setLabel('Privacy Policy')
                        .setURL('https://github.com/AkAbhijit/Apera-Documentation/blob/main/Privacy%20Policy.md')
                        .setStyle('LINK'),

                    new MessageButton()
                        .setLabel('Support Server')
                        .setURL(client.config.links.support)
                        .setStyle('LINK'),

                    new MessageButton()
                        .setLabel('Vote')
                        .setURL(client.config.links.vote)
                        .setStyle('LINK'),
                )

            info_commands = client.commands.filter((x) => x.category && x.category === "Information").map((x) => `\`${x.name}\``);
            music_commands = client.commands.filter((x) => x.category && x.category === "Music").map((x) => `\`${x.name}\``);
            filter_commands = client.commands.filter((x) => x.category && x.category === "Filters").map((x) => `\`${x.name}\``);
            playlist_commands = client.commands.filter((x) => x.category && x.category === "Playlist").map((x) => `\`${x.name}\``);
            settings_commands = client.commands.filter((x) => x.category && x.category === "Settings").map((x) => `\`${x.name}\``);
            owner_commands = client.commands.filter((x) => x.category && x.category === "Owner").map((x) => `\`${x.name}\``);

            const embed = new MessageEmbed()
                .setAuthor({ name: `Command Panel`, iconURL: client.user.displayAvatarURL() })
                .setColor(color)
                .addFields(
                    { name: `  Information`, value: `${info_commands.join(", ")}`, inline: false },
                    { name: `  Music`, value: `${music_commands.join(", ")}`, inline: false },
                    { name: `  Filters`, value: `${filter_commands.join(", ")}`, inline: false },
                    { name: `  Playlist`, value: `${playlist_commands.join(", ")}`, inline: false },
                    { name: `  Settings`, value: `${settings_commands.join(", ")}`, inline: false },
                    { name: `  Owner`, value: `${owner_commands.join(", ")}`, inline: false }

                )
                .setFooter({ text: `Type ?help <command> to view information of a specific command!` })
                message.channel.send({ embeds: [embed], components: [row] })
            }else{
                const command = await client.commands.get(args[0]);

      if (!command) {
        return message.reply({embeds: [new MessageEmbed().setDescription("Cannot find the command called **\"" + args[0] + "\"**")]});
      }

      let embedh = new MessageEmbed()
        .setTitle(command.name[0].toUpperCase() + command.name.slice(1) + " Help Command")
        .addField("Category", command.category ? "" +command.category + "" : "Not Provided")
        .addField("Description", command.description ? "`" +command.description + "`" : "Not Provided")
        .addField("Usage", command.usage ? "`" +prefix+command.usage + "`" : "Not Provided")
        .setColor(client.embedColor)


      if(command.aliases && command.aliases.length) embedh.addField("Aliases", command.aliases.map(x => "`[" + x +"]`").join(", "))
      if(command.botPermission && command.botPermission.length) embedh.addField("Bot Permissions", command.botPermission.map(x => "`[ " + x +" ]`").join(", "), true)
      if(command.authorPermission && command.authorPermission.length) embedh.addField("Author Permissions", command.authorPermission.map(x => "`[ " + x +"] `").join(", "), true)

      return message.channel.send({embeds: [embedh]});
            }



        } else {
            if(!args[0]){
        

            
            const color = client.embedColor

            var row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setLabel('Invite')
                        .setURL(client.config.links.invite)
                        .setStyle('LINK'),

                    new MessageButton()
                        .setLabel('Privacy Policy')
                        .setURL('https://github.com/AkAbhijit/Apera-Documentation/blob/main/Privacy%20Policy.md')
                        .setStyle('LINK'),

                    new MessageButton()
                        .setLabel('Support Server')
                        .setURL(client.config.links.support)
                        .setStyle('LINK'),

                    new MessageButton()
                        .setLabel('Vote')
                        .setURL('https://github.com/AkAbhijit/Apera-Documentation/blob/main/Privacy%20Policy.md')
                        .setStyle('LINK'),
                )

            info_commands = client.commands.filter((x) => x.category && x.category === "Information").map((x) => `\`${x.name}\``);
            music_commands = client.commands.filter((x) => x.category && x.category === "Music").map((x) => `\`${x.name}\``);
            filter_commands = client.commands.filter((x) => x.category && x.category === "Filters").map((x) => `\`${x.name}\``);
            playlist_commands = client.commands.filter((x) => x.category && x.category === "Playlist").map((x) => `\`${x.name}\``);
            settings_commands = client.commands.filter((x) => x.category && x.category === "Settings").map((x) => `\`${x.name}\``);

            const embed = new MessageEmbed()
                .setAuthor({ name: `Command Panel`, iconURL: client.user.displayAvatarURL() })
                .setColor(color)
                .addFields(
                    { name: `  Information`, value: `${info_commands.join(", ")}`, inline: false },
                    { name: `  Music`, value: `${music_commands.join(", ")}`, inline: false },
                    { name: `  Filters`, value: `${filter_commands.join(", ")}`, inline: false },
                    { name: `  Playlist`, value: `${playlist_commands.join(", ")}`, inline: false },
                    { name: `  Settings`, value: `${settings_commands.join(", ")}`, inline: false }

                )
                .setFooter({ text: `Type ?help <command> to view information of a specific command!` })

            message.channel.send({ embeds: [embed], components: [row] })
                } else {
                const command = await client.commands.get(args[0]);

                if (!command) {
                    return message.reply({ embeds: [new MessageEmbed().setDescription("Cannot find the command called **\"" + args[0] + "\"**")] });
                }

                let embedh = new MessageEmbed()
                    .setTitle(command.name[0].toUpperCase() + command.name.slice(1) + " Help Command")
                    .addField("Category", command.category ? "" + command.category + "" : "Not Provided")
                    .addField("Description", command.description ? "`" + command.description + "`" : "Not Provided")
                    .addField("Usage", command.usage ? "`" + prefix + command.usage + "`" : "Not Provided")
                    .setColor(client.embedColor)


                if (command.aliases && command.aliases.length) embedh.addField("Aliases", command.aliases.map(x => "`[" + x + "]`").join(", "))
                if (command.botPermission && command.botPermission.length) embedh.addField("Bot Permissions", command.botPermission.map(x => "`[ " + x + " ]`").join(", "), true)
                if (command.authorPermission && command.authorPermission.length) embedh.addField("Author Permissions", command.authorPermission.map(x => "`[ " + x + "] `").join(", "), true)

                return message.channel.send({ embeds: [embedh] });
            }
        }

    }
}
