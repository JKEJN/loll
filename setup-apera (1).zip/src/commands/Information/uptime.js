const { MessageEmbed, Message, Client } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");
const os = require("os");
const si = require("systeminformation");
module.exports = {
  name: "uptime",
  category: "Information",
  aliases: ["up"],
  description: "Shows Uptime status Of bot",
  args: false,
  usage: "",
  permission: [],
  owner: false,
  execute: async (message, args, client, prefix) => {

    const d = moment.duration(client.uptime);
    const days = d.days() == 1 ? `${d.days()}d` : `${d.days()}d`;
    const hours = d.hours() == 1 ? `${d.hours()}h` : `${d.hours()}h`;
    const minutes = d.minutes() == 1 ? `${d.minutes()}m` : `${d.minutes()}m`;
    const seconds = d.seconds() == 1 ? `${d.seconds()}s` : `${d.seconds()}s`;
    const embed = new MessageEmbed()
    .setDescription(`\`\`\`ini\n[ Uptime ] :: ${days} ${hours} ${minutes} ${seconds}\`\`\`\n`)
    .setColor(client.embedColor)
    message.reply({embeds:[embed]});
  },
};
