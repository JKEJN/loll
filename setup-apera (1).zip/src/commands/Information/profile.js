const { MessageEmbed } = require("discord.js");

module.exports = {
    name: "profile",
    category: "Information",
    description: "Check Ping Bot",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    execute: async (message, args, client, prefix) => {

        const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const aj = user.id === "952560202635427841" ? true : false;
        let badges = "";
        const guildd = await client.guilds.fetch("961893008893177898");
        const sus = await guildd.members.fetch(user.id).catch((e) => {
             badges = "No Achievements For this user";
            });
        if (aj === true || user.id === "959276033683628122") badges = badges + `\n<a:owner:965534543018872872> - **Creator**`;
        try {
            const own = sus.roles.cache.has("961893009325195305");
            if (own === true) badges = badges + `\n<a:owner:965534543018872872> - **Owner**`;

            const supp = sus.roles.cache.has("961893009295814683");
            if (supp === true) badges = badges + `\n<a:staffs:965535155143966740> - **Staff**`;

            const bug = sus.roles.cache.has("961893009295814684");
            if (bug === true) badges = badges + `\n<:bughunter:965535520698556446> - **Bug Hunter**`;

            const supo = sus.roles.cache.has("961893009295814682");
            if (supo === true) badges = badges + `\n<:supporter:965540217341739068> - **Supporter**`;

            const frn = sus.roles.cache.has("961893009295814678");
            if (frn === true) badges = badges + `\n<a:friends:965540114824581130> - **Friend**`;

        } catch (err) {}

        const embed = new MessageEmbed()
        .setAuthor({name:`Profile Of ${user.username}#${user.discriminator}`, iconURL:client.user.displayAvatarURL({ dynamic: true }), url: client.config.links.support })
            
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setColor(client.config.embedColor)
            .addField(`<a:achievements:965515828676161567> **Achievements**`, `${badges ? badges : "`No Badge Available`"}`)
            .setTimestamp();
        message.channel.send({ embeds: [embed] })
    }
}