const { MessageEmbed, MessageActionRow, MessageButton, WebhookClient, Permissions } = require("discord.js");
const db = require("../../schema/setup");
module.exports = {
    name: "setup",
    category: "Settings",
    description: "Set Custom Music channel",
    args: false,
    usage: "",
    aliases: [],
    permission: [""],
    owner: false,
  execute: async (message, args, client, prefix) => {
    try {
        let data = await db.findOne({ Guild: message.guildId });
        if(args.length) {
            if(!data) return await message.reply({content: `This server doesn't have any song request channel setup to use this sub command.`});
            if(["clear", "delete", "reset"].includes(args[0])) {
                const webhook = new WebhookClient({id:client.config.webhook.setupdata.id, token : client.config.webhook.setupdata.token})
                var send = `\`\`\`js\n${data}\`\`\``
                webhook.send(send);
                await data.delete();
                return await message.reply({content: `Successfully deleted all the setup data.`});

            } else return await message.reply({content: "Please provide a valid  command."});
        } else {
            if(data) return await message.reply({content: `Music setup is already finished in this server.`});
            if (!message.guild.me.permissions.has([Permissions.FLAGS.MANAGE_GUILD ])) return message.channel.send({
                embeds: [
                  new MessageEmbed()
                    .setColor(client.embedColor)
                    .setDescription(`I don't have enough permissions to execute this command! Please give me \`Manage Server\` Permission.`)]
              });
              if (!message.member.permissions.has('MANAGE_GUILD')) return message.channel.send({
                embeds: [
                  new MessageEmbed()
                    .setColor(client.embedColor)
                    .setDescription(`You must have \`Manage Guild\` permission to use this command.`)]
              });

            const parentChannel = await message.guild.channels.create(`${client.user.username} Music Zone`, { 
                type: "GUILD_CATEGORY",
                permissionOverwrites: [
                    {
                        type: "member",
                        id: message.guild.roles.cache.find((x) => x.name === "@everyone").id,
                        allow: ["CONNECT", "SPEAK", "VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS"],
                        deny: ["USE_APPLICATION_COMMANDS"]
                    },
                    {
                        type: "role",
                        id: message.guild.roles.cache.find((x) => x.name === "@everyone").id,
                        allow: ["VIEW_CHANNEL"],
                        deny: ["USE_APPLICATION_COMMANDS"]
                    }
                ]
            });

            const textChannel = await message.guild.channels.create(`${client.user.username}-song-requests`, {
                type: "GUILD_TEXT", 
                parent: parentChannel.id , 
                topic: '🔉Decreases 10% volume\n⏮️ Plays the previous track.\n⏯️ Pauses/resumes the player.\n⏭️ Skips the current track.\n🔊 Increases 10% volume.\n⏪ Rewinds the current track by 10 seconds.\n♾️ Toggles autoplay on/off.\n⏹️ Stops/destroys the player.\n🔁 Switches between the loop modes.\n⏩ Forwards the current track by 10 seconds.',
                permissionOverwrites: [
                    {
                        type: "member",
                        id: message.guild.roles.cache.find((x) => x.name === "@everyone").id,
                        allow: ["VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS", "READ_MESSAGE_HISTORY"],
                        deny: ["USE_APPLICATION_COMMANDS"]
                    },
                    {
                        type: "role",
                        id: message.guild.roles.cache.find((x) => x.name === "@everyone").id,
                        allow: ["VIEW_CHANNEL", "SEND_MESSAGES", "READ_MESSAGE_HISTORY"],
                        deny: ["USE_APPLICATION_COMMANDS"]
                    }
                ]
            });

            let rates = [1000*64, 1000*96, 1000*128, 1000*256, 1000*384];
            let rate = rates[0];

            switch(message.guild.premiumTier) {
                case "NONE":
                    rate = rates[1];
                    break;

                case "TIER_1":
                    rate = rates[2];
                    break;

                case "TIER_2":
                    rate = rates[3];
                    break;

                case "TIER_3":
                    rate = rates[4];
                    break;
            };

            const voiceChannel = await message.guild.channels.create(`${client.user.username} Music`, {
                type: "GUILD_VOICE",
                parent: parentChannel.id,
                bitrate: rate,
                userLimit: 35,
                permissionOverwrites: [
                    {
                        type: "member",
                        id: message.guild.roles.cache.find((x) => x.name === "@everyone").id,
                        allow: ["CONNECT", "SPEAK", "VIEW_CHANNEL", "REQUEST_TO_SPEAK"],
                        deny: ["USE_APPLICATION_COMMANDS"]
                        
                    },
                    {
                        type: "role",
                        id: message.guild.roles.cache.find((x) => x.name === "@everyone").id,
                        allow: ["CONNECT", "VIEW_CHANNEL"],
                        deny: ["SPEAK", "USE_APPLICATION_COMMANDS"]
                    }
                ]
            });


            let disabled = true;
            let player = client.manager.get(message.guildId);
            if(player) disabled = false;

            const title = player && player.queue && player.queue.current ? `Now playing` : "Nothing is playing right now";
            const desc = player && player.queue && player.queue.current ? `${player.queue.current.title}` : null;
            const footer = {
                text: `Made With 💖 By AkAbhijit`
            };
            const image =  client.config.links.img;

            let embed1 = new MessageEmbed().setColor(client.embedColor).setTitle(title).setFooter(footer).setImage(image);

            if(player && player.queue && player.queue.current) embed1.setDescription(desc);

            let pausebut = new MessageButton().setCustomId(`pause_but_${message.guildId}`).setEmoji("⏯️").setStyle("SECONDARY").setDisabled(disabled);

            let lowvolumebut = new MessageButton().setCustomId(`lowvolume_but_${message.guildId}`).setEmoji("🔉").setStyle("SECONDARY").setDisabled(disabled);

            let highvolumebut = new MessageButton().setCustomId(`highvolume_but_${message.guildId}`).setEmoji("🔊").setStyle("SECONDARY").setDisabled(disabled);

            let previousbut = new MessageButton().setCustomId(`previous_but_${message.guildId}`).setEmoji("⏮️").setStyle("SECONDARY").setDisabled(disabled);

            let skipbut = new MessageButton().setCustomId(`skipbut_but_${message.guildId}`).setEmoji("⏭️").setStyle("SECONDARY").setDisabled(disabled);

            let rewindbut = new MessageButton().setCustomId(`rewindbut_but_${message.guildId}`).setEmoji("⏪").setStyle("SECONDARY").setDisabled(disabled);

            let forwardbut = new MessageButton().setCustomId(`forward_but_${message.guildId}`).setEmoji("⏩").setStyle("SECONDARY").setDisabled(disabled);

            let savebut = new MessageButton().setCustomId(`save_but_${message.guildId}`).setEmoji("♾️").setStyle("SECONDARY").setDisabled(disabled);

            let loopmodesbut = new MessageButton().setCustomId(`loopmodesbut_but_${message.guildId}`).setEmoji("🔁").setStyle("SECONDARY").setDisabled(disabled);

            let stopbut = new MessageButton().setCustomId(`stop_but_${message.guildId}`).setEmoji("⏹️").setStyle("SECONDARY").setDisabled(disabled);

            const row1 = new MessageActionRow().addComponents(lowvolumebut, previousbut, pausebut, skipbut, highvolumebut);

            const row2 = new MessageActionRow().addComponents(rewindbut, savebut, stopbut, loopmodesbut, forwardbut);

            const msg = await textChannel.send({
                embeds: [embed1],
                components: [row1, row2]
            });

           const Ndata = new db({
                Guild: message.guildId,
                Channel: textChannel.id,
                Message: msg.id,
                voiceChannel: voiceChannel.id,
            });

            await Ndata.save();
            return await message.channel.send({
                embeds: [new MessageEmbed().setColor(client.embedColor).setTitle("Setup Finished").setDescription(`**Song request channel has been created.**\n\nChannel: ${textChannel}\n\nNote: Deleting the template embed in there may cause this setup to stop working. (Please don't delete it.)*`).setAuthor({name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true })})]
            });
        };
    } catch (error) {
        console.error(new Error(error));
    };
}
}
